
import React from "react";
import {createRoot} from "react-dom/client";
import {Rocket,BookOpen,Briefcase,Users,Trophy} from "lucide-react";
import "./style.css";

function App(){
return <div>
<header>
<div className="logo">S SkillLink</div>
<nav>Home About Programs Courses Projects Partner Login</nav>
</header>

<section className="hero">
<div>
<p>LEARN • BUILD • EARN</p>
<h1>Build Your Skills.<br/><span>Build Your Future.</span></h1>
<p>SkillLink is an entrepreneur skill ecosystem connecting learning, practical projects and opportunities.</p>
<button>Get Started</button>
</div>
<Rocket size={100}/>
</section>

<section className="cards">
{[
["Programs","Premium skill programs",BookOpen],
["Projects","Real practical opportunities",Briefcase],
["Community","Partners and learners",Users],
["Growth","Level and rewards journey",Trophy]
].map(([a,b,I])=><div className="card"><I/><h2>{a}</h2><p>{b}</p></div>)}
</section>

<section className="packages">
<h2>SkillLink Programs</h2>
<div className="grid">
{["Aarambh ₹499","Udaan ₹999","Pragati ₹1999","Brahmastra ₹3999","Shikhar ₹6999"].map(x=><div className="box">{x}</div>)}
</div>
</section>

<footer>© SkillLink • Learn Master Build Earn Grow</footer>
</div>
}
createRoot(document.getElementById("root")).render(<App/>)
