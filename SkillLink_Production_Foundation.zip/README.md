# SkillLink — Production Foundation

This repository is the first production foundation for the SkillLink full-stack platform described in the Master Prompt.

## Stack

- React + Vite
- Supabase Auth
- Supabase PostgreSQL
- Supabase Row Level Security
- Supabase Storage (configure buckets for protected uploads)
- Vercel frontend

## 1. Supabase

Open Supabase → SQL Editor and run:

`supabase/schema.sql`

This creates the core relational schema, packages, levels, permissions, score ledger, financial ledger, projects, notifications and security policies.

After running it, create your first CEO securely:
1. Create the user in Supabase Authentication.
2. Find the generated auth user UUID.
3. In `public.users`, change that user's role to `CEO` and status to `ACTIVE`.
4. Never place the CEO password in frontend code or GitHub.

## 2. Local setup

```bash
npm install
cp .env.example .env
npm run dev
```

Set:

```env
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
```

## 3. GitHub

Upload the repository contents. Do NOT upload `.env`.

## 4. Vercel

Import the GitHub repository. Add the same VITE environment variables in Vercel and deploy.

`vercel.json` provides SPA routing.

## Important production notes

This repository deliberately does not contain production passwords or service-role keys.

The frontend is a real application shell connected to Supabase Auth and core data architecture. Sensitive operations must remain server-side/RLS protected. Expand the remaining CRUD workflows using the same authorization model before opening the platform broadly.

Do not treat demo balances or sample rows in the UI as real financial balances. Real earnings must be created from verified project/payment events in the database.

## Business rules already represented

- Package prices and partner commissions from the SkillLink Master Prompt.
- L1-L9 score thresholds.
- Score categories and score ledger.
- ₹100 minimum withdrawal.
- Project default 20% company / 80% partner configuration.
- 2 default project revisions.
- ₹10,000 / 45-day refund configuration.
