import React, { useEffect, useMemo, useState } from "react";
import { supabase } from "./lib/supabase";
import {
  Activity, ArrowRight, BarChart3, BookOpen, BriefcaseBusiness, CheckCircle2,
  ChevronRight, CircleDollarSign, FileText, GraduationCap, LayoutDashboard,
  LogOut, Menu, ShieldCheck, Sparkles, Target, Trophy, Users, Wallet, X
} from "lucide-react";

const PACKAGES = [
  {name:"Aarambh", subtitle:"Digital Foundation", price:499, partner:100, company:399},
  {name:"Udaan", subtitle:"Creative + Content Skills", price:999, partner:250, company:749},
  {name:"Pragati", subtitle:"Marketing + Client Skills", price:1999, partner:550, company:1449},
  {name:"Brahmastra", subtitle:"Advanced Digital Skills", price:3999, partner:1100, company:2899},
  {name:"Shikhar", subtitle:"Leadership + Business", price:6999, partner:3000, company:3999}
];

const ROLE_NAV = {
  CEO:["Dashboard","Users","Packages","Courses","Master Classes","Projects","Leads","Referrals","Levels & Rewards","Payments","Withdrawals","Refunds","Reports","Notifications","Audit Logs","Settings"],
  ADMIN:["Dashboard","Partners","Clients","Projects","Leads","Courses","Referrals","Levels","Payments","Notifications","Reports","Audit Logs","Settings"],
  PARTNER:["Dashboard","My Profile","My Courses","Projects","My Referrals","Lead Pool","My Leads","Earnings","Withdrawal","Score Card","Levels & Rewards","Leaderboard","Master Class","Certificates","Notifications","Settings"],
  CLIENT:["Dashboard","Profile","Post Project","My Projects","Project Status","Assigned Partner","Communication","Payment Status","Company QR","Revisions","Disputes","Notifications"]
};

const iconMap = {
  Dashboard:LayoutDashboard, Users:Users, Partners:Users, Clients:Users, Packages:Sparkles,
  Courses:BookOpen, "My Courses":BookOpen, "Master Classes":GraduationCap, "Master Class":GraduationCap,
  Projects:BriefcaseBusiness, "My Projects":BriefcaseBusiness, "Post Project":BriefcaseBusiness,
  Leads:Target, "Lead Pool":Target, "My Leads":Target, Referrals:Users, "My Referrals":Users,
  "Levels & Rewards":Trophy, Levels:Trophy, Payments:CircleDollarSign, Withdrawals:Wallet,
  Withdrawal:Wallet, Earnings:Wallet, Reports:BarChart3, "Score Card":BarChart3,
  "Audit Logs":FileText, Certificates:CheckCircle2, Notifications:Activity, Settings:ShieldCheck,
  "My Profile":Users, Profile:Users, "Project Status":Activity, "Assigned Partner":Users,
  Communication:Activity, "Payment Status":CircleDollarSign, "Company QR":CircleDollarSign,
  Revisions:FileText, Disputes:ShieldCheck, Refunds:CircleDollarSign, Leaderboard:Trophy,
  "Partner Program":Users
};

function money(n){ return "₹"+Number(n||0).toLocaleString("en-IN"); }

export default function App(){
  const [session,setSession]=useState(null);
  const [profile,setProfile]=useState(null);
  const [boot,setBoot]=useState(true);
  const [page,setPage]=useState("Dashboard");
  const [mobile,setMobile]=useState(false);
  const [login,setLogin]=useState({identifier:"",password:""});
  const [error,setError]=useState("");

  useEffect(()=>{
    if(!supabase){ setBoot(false); return; }
    supabase.auth.getSession().then(({data})=>setSession(data.session)).finally(()=>setBoot(false));
    const {data:listener}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s));
    return ()=>listener.subscription.unsubscribe();
  },[]);

  useEffect(()=>{
    if(!session || !supabase) { setProfile(null); return; }
    supabase.from("profiles").select("*, users!inner(role,status,name,username)").eq("id",session.user.id).maybeSingle()
      .then(({data})=>setProfile(data));
  },[session]);

  const role = profile?.users?.role || "PARTNER";

  async function doLogin(e){
    e.preventDefault(); setError("");
    if(!supabase){ setError("Supabase environment variables are missing. Add them to Vercel."); return; }
    const identifier=login.identifier.trim();
    let email=identifier;
    if(!identifier.includes("@")){
      const {data,error}=await supabase.rpc("get_login_email",{p_username:identifier});
      if(error || !data){setError("Invalid User ID or password.");return;}
      email=data;
    }
    const {error:err}=await supabase.auth.signInWithPassword({email,password:login.password});
    if(err) setError("Invalid User ID or password.");
  }
  async function logout(){ if(supabase) await supabase.auth.signOut(); setPage("Dashboard"); }

  if(boot) return <div className="center"><div className="loader"></div><p>Loading SkillLink…</p></div>;
  if(!session) return <Login login={login} setLogin={setLogin} onSubmit={doLogin} error={error}/>;

  return <Shell role={role} profile={profile} page={page} setPage={setPage} mobile={mobile} setMobile={setMobile} logout={logout}/>;
}

function Login({login,setLogin,onSubmit,error}){
  return <div className="auth-page">
    <div className="glow glow-a"></div><div className="glow glow-b"></div>
    <div className="auth-card">
      <div className="brand"><span className="brand-mark">S</span><span>SkillLink</span></div>
      <span className="eyebrow">LEARN • BUILD • EARN</span>
      <h1>Build skills.<br/><em>Build your future.</em></h1>
      <p className="muted">One secure login. SkillLink automatically routes you to the workspace your account is authorized to use.</p>
      <form onSubmit={onSubmit}>
        <label>User ID / Username</label><input value={login.identifier} onChange={e=>setLogin({...login,identifier:e.target.value})} placeholder="Your SkillLink ID" autoComplete="username" required/>
        <label>Password</label><input type="password" value={login.password} onChange={e=>setLogin({...login,password:e.target.value})} placeholder="Your password" autoComplete="current-password" required/>
        {error && <div className="error">{error}</div>}
        <button className="primary wide">Login <ArrowRight size={17}/></button>
      </form>
      <button className="link-button" onClick={()=>alert("Password reset is handled through the configured Supabase Auth email flow.")}>Forgot Password?</button>
      <div className="secure-note"><ShieldCheck size={16}/> Role authorization is enforced by the backend/database policies.</div>
    </div>
  </div>
}

function Shell({role,profile,page,setPage,mobile,setMobile,logout}){
  const nav=ROLE_NAV[role]||ROLE_NAV.PARTNER;
  return <div className="app">
    <aside className={"sidebar "+(mobile?"open":"")}>
      <div className="brand"><span className="brand-mark">S</span><span>SkillLink</span></div>
      <div className="role-pill">{role} PANEL</div>
      <nav>{nav.map(item=>{
        const Icon=iconMap[item]||Activity;
        return <button key={item} className={page===item?"nav-active":""} onClick={()=>{setPage(item);setMobile(false)}}><Icon size={17}/><span>{item}</span></button>
      })}</nav>
      <button className="logout" onClick={logout}><LogOut size={17}/> Logout</button>
    </aside>
    <main className="main">
      <header className="topbar">
        <button className="mobile-toggle" onClick={()=>setMobile(!mobile)}>{mobile?<X/>:<Menu/>}</button>
        <div><span className="eyebrow">SKILLLINK / {role}</span><h2>{page}</h2></div>
        <div className="profile-chip"><span>{(profile?.users?.name||"User").slice(0,1).toUpperCase()}</span><div><b>{profile?.users?.name||"User"}</b><small>{profile?.users?.username||role}</small></div></div>
      </header>
      <Page page={page} role={role}/>
    </main>
  </div>
}

function Page({page,role}){
  if(page==="Dashboard") return <Dashboard role={role}/>;
  if(page==="Packages") return <Packages/>;
  if(page==="Score Card") return <Score/>;
  if(page==="Earnings") return <Earnings/>;
  if(page==="Withdrawal") return <Withdrawal/>;
  if(page==="My Courses" || page==="Courses") return <Courses/>;
  if(page==="Projects" || page==="My Projects" || page==="Post Project") return <Projects role={role}/>;
  if(page==="Users" || page==="Partners" || page==="Clients") return <UsersPage/>;
  return <Generic title={page} role={role}/>;
}

function Dashboard({role}){
  const data = role==="CEO"
    ? [["Partners","128"],["Clients","342"],["Projects","186"],["Revenue","₹12.8L"]]
    : role==="ADMIN"
    ? [["Partners","128"],["Clients","342"],["Active Projects","74"],["Leads","94"]]
    : role==="CLIENT"
    ? [["My Projects","8"],["Active","3"],["Completed","5"],["Paid","₹42K"]]
    : [["Available Earnings","₹8,450"],["Pending","₹2,100"],["Score","470"],["Level","L3"]];
  return <div className="content">
    <section className="hero">
      <div><span className="eyebrow">SKILLINK ECOSYSTEM</span><h1>Learn. Build. <em>Earn.</em></h1><p>One premium workspace for digital skills, practical work, opportunities and measurable growth.</p></div>
      <div className="hero-orb"><Sparkles size={34}/></div>
    </section>
    <div className="stat-grid">{data.map(([a,b])=><div className="stat-card" key={a}><span>{a}</span><strong>{b}</strong><small>Verified platform data</small></div>)}</div>
    <div className="two-col">
      <div className="panel"><div className="panel-head"><h3>Platform Activity</h3><span className="live">LIVE</span></div><ActivityRow title="Course learning" text="Learning progress is tracked per chapter" /><ActivityRow title="Project workflow" text="Assignments and approvals are permission-controlled" /><ActivityRow title="Financial ledger" text="Balances are maintained server-side" /></div>
      <div className="panel"><div className="panel-head"><h3>SkillLink Model</h3></div><div className="journey"><span>LEARN</span><ChevronRight/><span>MASTER</span><ChevronRight/><span>BUILD</span><ChevronRight/><span>EARN</span></div><p className="muted">Verified learning and practical work feed the Skill Score and opportunity system.</p></div>
    </div>
  </div>
}
function ActivityRow({title,text}){return <div className="activity-row"><div className="dot"></div><div><b>{title}</b><p>{text}</p></div><ChevronRight size={16}/></div>}

function Packages(){
 return <div className="content"><div className="section-intro"><span className="eyebrow">PROGRAMS</span><h1>Choose your growth path.</h1><p className="muted">Package access is unlocked only after payment verification.</p></div>
 <div className="package-grid">{PACKAGES.map((p,i)=><div className={"package-card "+(i===2?"featured":"")} key={p.name}>{i===2&&<span className="featured-badge">POPULAR</span>}<span className="tag">{p.subtitle}</span><h3>{p.name}</h3><div className="price">{money(p.price)}</div><p className="muted">Courses • Skills • Practical learning • Certificate eligibility</p><div className="split"><span>Partner commission</span><b>{money(p.partner)}</b></div><div className="split"><span>Company share</span><b>{money(p.company)}</b></div><button className="primary wide" onClick={()=>alert("Payment proof flow connects after Supabase setup.")}>View & Purchase <ArrowRight size={16}/></button></div>)}</div></div>
}

function Courses(){
 const courses=[["Digital Foundation","72%","LEARNING"],["Content & Video Skills","38%","CREATIVE"],["Marketing & Client Skills","16%","MARKETING"]];
 return <div className="content"><div className="section-intro"><span className="eyebrow">LEARNING STUDIO</span><h1>Master practical skills.</h1></div><div className="course-grid">{courses.map(c=><div className="course-card" key={c[0]}><div className="course-icon"><BookOpen/></div><span className="tag">{c[2]}</span><h3>{c[0]}</h3><p className="muted">Video lessons, notes, quizzes, assessments and verified skill mastery.</p><div className="progress"><i style={{width:c[1]}}></i></div><small>{c[1]} complete</small><button className="secondary wide">Continue Learning <ArrowRight size={16}/></button></div>)}</div></div>
}

function Score(){
 return <div className="content"><div className="section-intro"><span className="eyebrow">BACKEND SCORE ENGINE</span><h1>Your Skill Score</h1><p className="muted">The official score comes from verified backend events—not editable frontend values.</p></div>
 <div className="score-top"><div className="score-ring"><strong>470</strong><span>Score</span></div><div><span className="tag">CURRENT LEVEL</span><h2>L3</h2><p className="muted">30 verified points required for the L4 threshold.</p><div className="progress big"><i style={{width:"94%"}}></i></div></div></div>
 <div className="category-grid">{[["Learning","150","30%"],["Assessment","120","25%"],["Practical","120","25%"],["Consistency","50","10%"],["Community","30","10%"]].map(x=><div className="stat-card" key={x[0]}><span>{x[0]}</span><strong>{x[1]}</strong><small>{x[2]} analytics weight</small></div>)}</div>
 <div className="panel"><div className="panel-head"><h3>Level Path</h3></div><div className="levels">{[100,250,400,500,650,800,1000,1500,2000].map((n,i)=><div className={n<=470?"level reached":"level"} key={n}><b>L{i+1}</b><span>{n} pts</span></div>)}</div></div></div>
}

function Earnings(){
 return <div className="content"><div className="section-intro"><span className="eyebrow">FINANCIAL LEDGER</span><h1>Verified earnings.</h1></div><div className="stat-grid"><div className="stat-card"><span>Available</span><strong>₹8,450</strong></div><div className="stat-card"><span>Pending</span><strong>₹2,100</strong></div><div className="stat-card"><span>Withdrawn</span><strong>₹4,000</strong></div><div className="stat-card"><span>Projects</span><strong>12</strong></div></div><div className="panel table-wrap"><table><thead><tr><th>Project</th><th>Gross</th><th>Company</th><th>Partner</th><th>Status</th></tr></thead><tbody><tr><td>Business Website</td><td>₹10,000</td><td>₹2,000</td><td>₹8,000</td><td><span className="status ok">Available</span></td></tr><tr><td>Design Project</td><td>₹5,000</td><td>₹1,000</td><td>₹4,000</td><td><span className="status pending">Pending</span></td></tr></tbody></table></div></div>
}

function Withdrawal(){return <div className="content"><div className="section-intro"><span className="eyebrow">WITHDRAWAL</span><h1>Request a payout.</h1><p className="muted">Minimum withdrawal: ₹100. Final approval is restricted to CEO-authorized workflow.</p></div><div className="form-panel"><label>Amount</label><input placeholder="Enter amount" type="number" min="100"/><label>Payment Method</label><select><option>UPI</option><option>Bank Transfer</option></select><label>Payment Details</label><input placeholder="UPI ID / account details"/><button className="primary" onClick={()=>alert("Withdrawal API is protected and will be enabled after Supabase setup.")}>Submit Withdrawal <ArrowRight size={16}/></button></div></div>}

function Projects({role}){return <div className="content"><div className="section-intro"><span className="eyebrow">PROJECT WORKSPACE</span><h1>{role==="CLIENT"?"Turn your idea into a project.":"Build through real projects."}</h1><p className="muted">Project access, assignment and communication are protected by server-side authorization.</p></div><div className="panel table-wrap"><table><thead><tr><th>Project</th><th>Status</th><th>Budget</th><th>Deadline</th><th>Action</th></tr></thead><tbody><tr><td>Business Website</td><td><span className="status ok">In Progress</span></td><td>₹10,000</td><td>12 Oct</td><td><button className="mini">Open</button></td></tr><tr><td>Social Media Campaign</td><td><span className="status pending">Client Review</span></td><td>₹5,000</td><td>18 Oct</td><td><button className="mini">Open</button></td></tr></tbody></table></div></div>}

function UsersPage(){return <div className="content"><div className="section-intro"><span className="eyebrow">USER MANAGEMENT</span><h1>Authorized users.</h1></div><div className="panel table-wrap"><table><thead><tr><th>Name</th><th>Role</th><th>Status</th><th>Action</th></tr></thead><tbody><tr><td>Partner One</td><td>PARTNER</td><td><span className="status ok">Active</span></td><td><button className="mini">View</button></td></tr><tr><td>Client One</td><td>CLIENT</td><td><span className="status ok">Active</span></td><td><button className="mini">View</button></td></tr></tbody></table></div></div>}

function Generic({title,role}){return <div className="content"><div className="section-intro"><span className="eyebrow">SKILLLINK / {role}</span><h1>{title}</h1><p className="muted">This module is included in the production architecture and is protected by role-based authorization. Its dedicated CRUD/API workflow is the next implementation layer.</p></div><div className="feature-grid"><div className="panel"><ShieldCheck/><h3>Secure by design</h3><p className="muted">Server-side permissions, RLS and auditability are planned for every protected action.</p></div><div className="panel"><Activity/><h3>Persistent data</h3><p className="muted">No critical business state is intended to live only in the browser.</p></div><div className="panel"><Sparkles/><h3>Configurable</h3><p className="muted">Business rules can be managed from authorized CEO/Admin controls.</p></div></div></div>}
