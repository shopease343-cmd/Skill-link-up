-- SKILLLINK PRODUCTION DATABASE
-- Run this entire file in Supabase SQL Editor.
-- Auth identities are stored by Supabase Auth; public.users stores application roles.

create extension if not exists pgcrypto;

create type public.app_role as enum ('CEO','ADMIN','PARTNER','CLIENT');
create type public.user_status as enum ('ACTIVE','SUSPENDED','DEACTIVATED','PENDING');
create type public.payment_status as enum ('PENDING','VERIFIED','REJECTED','RESUBMISSION_REQUIRED');
create type public.project_status as enum ('NEW','REVIEW','APPROVED','AVAILABLE','INTEREST_EXPRESSED','ASSIGNED','IN_PROGRESS','SUBMITTED','CLIENT_REVIEW','REVISION_REQUESTED','COMPLETED','DISPUTED','CANCELLED');
create type public.withdrawal_status as enum ('PENDING','UNDER_REVIEW','APPROVED','REJECTED','PAID','FAILED');
create type public.score_category as enum ('LEARNING','ASSESSMENT','PRACTICAL','CONSISTENCY','COMMUNITY');
create type public.score_event_status as enum ('PENDING','VERIFIED','REJECTED','CANCELLED');

create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.app_role not null default 'PARTNER',
  status public.user_status not null default 'PENDING',
  name text not null default '',
  username text not null unique,
  mobile text,
  email text,
  package_id uuid,
  first_login_password_change boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references public.users(id) on delete cascade,
  avatar_url text,
  bio text,
  city text,
  state text,
  upi_id text,
  bank_details jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.permissions (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  description text,
  created_at timestamptz not null default now()
);

create table if not exists public.user_permissions (
  user_id uuid references public.users(id) on delete cascade,
  permission_id uuid references public.permissions(id) on delete cascade,
  granted_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  primary key(user_id,permission_id)
);

create table if not exists public.packages (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  subtitle text not null,
  price numeric(12,2) not null check(price >= 0),
  partner_commission numeric(12,2) not null default 0 check(partner_commission >= 0),
  company_share numeric(12,2) not null default 0 check(company_share >= 0),
  description text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.users drop constraint if exists users_package_id_fkey;
alter table public.users add constraint users_package_id_fkey foreign key(package_id) references public.packages(id);

create table if not exists public.package_purchases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id),
  package_id uuid not null references public.packages(id),
  amount numeric(12,2) not null,
  transaction_id text,
  proof_path text,
  paid_at timestamptz,
  status public.payment_status not null default 'PENDING',
  verified_by uuid references public.users(id),
  verified_at timestamptz,
  remarks text,
  created_at timestamptz not null default now()
);

create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  thumbnail_path text,
  package_id uuid references public.packages(id),
  category text,
  status text not null default 'DRAFT' check(status in ('DRAFT','PREVIEW','PUBLISHED','ARCHIVED')),
  certificate_eligible boolean not null default false,
  created_by uuid references public.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.course_modules (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  name text not null,
  sort_order int not null default 0
);

create table if not exists public.course_chapters (
  id uuid primary key default gen_random_uuid(),
  module_id uuid not null references public.course_modules(id) on delete cascade,
  name text not null,
  sort_order int not null default 0
);

create table if not exists public.course_content (
  id uuid primary key default gen_random_uuid(),
  chapter_id uuid not null references public.course_chapters(id) on delete cascade,
  content_type text not null check(content_type in ('VIDEO','NOTES','PDF','LINK')),
  title text not null,
  video_url text,
  file_path text,
  sort_order int not null default 0
);

create table if not exists public.course_progress (
  user_id uuid references public.users(id) on delete cascade,
  content_id uuid references public.course_content(id) on delete cascade,
  progress_percent numeric(5,2) not null default 0 check(progress_percent between 0 and 100),
  completed_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key(user_id,content_id)
);

create table if not exists public.assessments (
  id uuid primary key default gen_random_uuid(),
  course_id uuid references public.courses(id) on delete cascade,
  title text not null,
  level text not null default 'BASIC',
  pass_percent numeric(5,2) not null default 60,
  points int not null default 20,
  active boolean not null default true
);

create table if not exists public.assessment_attempts (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid not null references public.assessments(id),
  user_id uuid not null references public.users(id),
  score_percent numeric(5,2) not null,
  passed boolean not null,
  answers jsonb,
  submitted_at timestamptz not null default now()
);

create table if not exists public.skill_mastery (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  skill_name text not null,
  verified boolean not null default false,
  verified_by uuid references public.users(id),
  verified_at timestamptz,
  unique(user_id,skill_name)
);

create table if not exists public.certificates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id),
  course_id uuid not null references public.courses(id),
  certificate_id text unique not null,
  verification_code text unique not null,
  completion_date date not null default current_date,
  details jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references public.users(id),
  referred_id uuid not null unique references public.users(id),
  referral_code text not null,
  registration_at timestamptz not null default now(),
  activation_at timestamptz,
  package_id uuid references public.packages(id),
  valid boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.score_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  category public.score_category not null,
  event_type text not null,
  points int not null,
  reference_id uuid,
  status public.score_event_status not null default 'VERIFIED',
  description text,
  approved_by uuid references public.users(id),
  metadata jsonb,
  event_date date not null default current_date,
  created_at timestamptz not null default now()
);

create unique index if not exists score_event_unique_ref on public.score_events(user_id,event_type,reference_id) where reference_id is not null;
create unique index if not exists score_daily_unique on public.score_events(user_id,event_type,event_date) where event_type like 'DAILY_%';

create table if not exists public.score_balances (
  user_id uuid primary key references public.users(id) on delete cascade,
  total_score int not null default 0,
  learning_score int not null default 0,
  assessment_score int not null default 0,
  practical_score int not null default 0,
  consistency_score int not null default 0,
  community_score int not null default 0,
  current_level int not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists public.levels (
  id int primary key,
  name text not null,
  threshold int not null unique,
  active boolean not null default true
);

create table if not exists public.level_requirements (
  id uuid primary key default gen_random_uuid(),
  level_id int not null references public.levels(id) on delete cascade,
  required_score int not null,
  required_referrals int not null default 0,
  required_skill_masteries int not null default 0,
  required_courses int not null default 0,
  required_practical_tasks int not null default 0,
  config jsonb not null default '{}'::jsonb,
  updated_by uuid references public.users(id),
  updated_at timestamptz not null default now(),
  unique(level_id)
);

create table if not exists public.rewards (
  id uuid primary key default gen_random_uuid(),
  level_id int references public.levels(id),
  title text not null,
  description text,
  eligibility jsonb,
  active boolean not null default true
);

create table if not exists public.reward_claims (
  id uuid primary key default gen_random_uuid(),
  reward_id uuid references public.rewards(id),
  user_id uuid references public.users(id),
  status text not null default 'ELIGIBLE',
  claimed_at timestamptz,
  approved_by uuid references public.users(id),
  remarks text
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  required_skills text[],
  budget numeric(12,2) not null default 0,
  deadline date,
  priority text default 'NORMAL',
  client_id uuid references public.users(id),
  created_by uuid not null references public.users(id),
  status public.project_status not null default 'NEW',
  attachments jsonb,
  revision_limit int not null default 2,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.project_assignments (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  partner_id uuid not null references public.users(id),
  assigned_by uuid not null references public.users(id),
  assigned_at timestamptz not null default now(),
  status text not null default 'ACTIVE',
  unique(project_id)
);

create table if not exists public.project_revisions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  requested_by uuid not null references public.users(id),
  description text not null,
  revision_number int not null,
  status text not null default 'REQUESTED',
  created_at timestamptz not null default now()
);

create table if not exists public.project_disputes (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  opened_by uuid not null references public.users(id),
  reason text not null,
  description text,
  status text not null default 'OPEN',
  decision text,
  decided_by uuid references public.users(id),
  decided_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.project_messages (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  sender_id uuid not null references public.users(id),
  message text not null,
  attachments jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.project_earnings (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null unique references public.projects(id),
  partner_id uuid not null references public.users(id),
  gross_amount numeric(12,2) not null,
  company_share numeric(12,2) not null,
  partner_share numeric(12,2) not null,
  status text not null default 'PENDING',
  available_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.earnings_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id),
  project_id uuid references public.projects(id),
  entry_type text not null,
  gross_amount numeric(12,2) not null default 0,
  company_share numeric(12,2) not null default 0,
  partner_share numeric(12,2) not null default 0,
  amount numeric(12,2) not null,
  status text not null,
  reference_id uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  partner_id uuid not null references public.users(id),
  amount numeric(12,2) not null check(amount >= 100),
  payment_method text not null,
  payment_details jsonb not null,
  status public.withdrawal_status not null default 'PENDING',
  request_date timestamptz not null default now(),
  approved_by uuid references public.users(id),
  approved_at timestamptz,
  paid_at timestamptz,
  payment_reference text,
  remarks text
);

create table if not exists public.refund_requests (
  id uuid primary key default gen_random_uuid(),
  purchase_id uuid not null references public.package_purchases(id),
  user_id uuid not null references public.users(id),
  purchase_date timestamptz not null,
  eligibility_date timestamptz not null,
  skilllink_earnings numeric(12,2) not null default 0,
  threshold numeric(12,2) not null default 10000,
  eligible boolean not null default false,
  status text not null default 'PENDING',
  decision_by uuid references public.users(id),
  decision_at timestamptz,
  remarks text,
  created_at timestamptz not null default now()
);

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  source text,
  partner_id uuid references public.users(id),
  client_id uuid references public.users(id),
  assigned_by uuid references public.users(id),
  status text not null default 'NEW',
  notes text,
  converted boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  title text not null,
  body text not null,
  type text not null,
  link text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.users(id),
  action text not null,
  target_type text,
  target_id uuid,
  before_data jsonb,
  after_data jsonb,
  metadata jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.company_settings (
  id boolean primary key default true,
  company_name text not null default 'SkillLink',
  upi_id text,
  qr_path text,
  payment_instructions text,
  project_company_percent numeric(5,2) not null default 20,
  project_partner_percent numeric(5,2) not null default 80,
  min_withdrawal numeric(12,2) not null default 100,
  revision_limit int not null default 2,
  refund_earning_threshold numeric(12,2) not null default 10000,
  refund_window_days int not null default 45,
  leaderboard_enabled boolean not null default true,
  updated_at timestamptz not null default now()
);

insert into public.company_settings default values on conflict do nothing;

insert into public.packages(name,subtitle,price,partner_commission,company_share) values
('Aarambh','Digital Foundation',499,100,399),
('Udaan','Creative + Content Skills',999,250,749),
('Pragati','Marketing + Client Skills',1999,550,1449),
('Brahmastra','Advanced Digital Skills',3999,1100,2899),
('Shikhar','Leadership + Business',6999,3000,3999)
on conflict(name) do update set subtitle=excluded.subtitle,price=excluded.price,partner_commission=excluded.partner_commission,company_share=excluded.company_share;

insert into public.levels(id,name,threshold) values
(1,'L1 Starter Partner',100),(2,'L2 Rising Partner',250),(3,'L3',400),(4,'L4',500),(5,'L5',650),(6,'L6',800),(7,'L7',1000),(8,'L8',1500),(9,'L9',2000)
on conflict(id) do update set threshold=excluded.threshold,name=excluded.name;

insert into public.level_requirements(level_id,required_score) values
(1,100),(2,250),(3,400),(4,500),(5,650),(6,800),(7,1000),(8,1500),(9,2000)
on conflict(level_id) do nothing;

insert into public.permissions(code,description) values
('manage_partners','Manage partners'),('manage_clients','Manage clients'),('manage_projects','Manage projects'),
('manage_courses','Manage courses'),('manage_leads','Manage leads'),('manage_referrals','Manage referrals'),
('manage_levels','Manage levels'),('view_payments','View payments'),('manage_notifications','Manage notifications'),
('view_reports','View reports'),('view_audit_logs','View audit logs')
on conflict(code) do nothing;

-- Helper: safely get email for a username without exposing role/permissions.
create or replace function public.get_login_email(p_username text)
returns text
language sql
security definer
set search_path=public
as $$
  select email from public.users where lower(username)=lower(trim(p_username)) and status <> 'DEACTIVATED' limit 1;
$$;
revoke all on function public.get_login_email(text) from public;
grant execute on function public.get_login_email(text) to anon,authenticated;

-- Score calculation from authoritative score_events.
create or replace function public.recalculate_score(p_user_id uuid)
returns public.score_balances
language plpgsql
security definer
set search_path=public
as $$
declare r public.score_balances;
begin
  insert into public.score_balances(user_id)
  values(p_user_id) on conflict(user_id) do nothing;

  select * into r from (
    select p_user_id as user_id,
      coalesce(sum(points) filter(where status='VERIFIED'),0)::int total_score,
      coalesce(sum(points) filter(where status='VERIFIED' and category='LEARNING'),0)::int learning_score,
      coalesce(sum(points) filter(where status='VERIFIED' and category='ASSESSMENT'),0)::int assessment_score,
      coalesce(sum(points) filter(where status='VERIFIED' and category='PRACTICAL'),0)::int practical_score,
      coalesce(sum(points) filter(where status='VERIFIED' and category='CONSISTENCY'),0)::int consistency_score,
      coalesce(sum(points) filter(where status='VERIFIED' and category='COMMUNITY'),0)::int community_score
    from public.score_events where user_id=p_user_id
  ) s;

  r.current_level := coalesce((select max(id) from public.levels where threshold <= r.total_score),0);

  update public.score_balances set
    total_score=r.total_score,learning_score=r.learning_score,assessment_score=r.assessment_score,
    practical_score=r.practical_score,consistency_score=r.consistency_score,
    community_score=r.community_score,current_level=r.current_level,updated_at=now()
  where user_id=p_user_id returning * into r;

  return r;
end;
$$;

-- Create an approved score event. No public arbitrary-point endpoint is provided.
create or replace function public.create_score_event(
  p_user_id uuid,p_category public.score_category,p_event_type text,p_points int,
  p_reference_id uuid default null,p_description text default null,p_metadata jsonb default '{}'::jsonb
)
returns public.score_events
language plpgsql
security definer
set search_path=public
as $$
declare e public.score_events;
begin
  if auth.uid() is null or auth.uid() <> p_user_id then
    raise exception 'Unauthorized';
  end if;
  if p_points < 0 or p_points > 100 then raise exception 'Invalid points'; end if;

  insert into public.score_events(user_id,category,event_type,points,reference_id,description,metadata,status)
  values(p_user_id,p_category,p_event_type,p_points,p_reference_id,p_description,p_metadata,'VERIFIED')
  on conflict do nothing
  returning * into e;

  if e.id is not null then perform public.recalculate_score(p_user_id); end if;
  return e;
end;
$$;

-- Withdrawal request: balance is calculated from ledger and pending withdrawals.
create or replace function public.request_withdrawal(p_amount numeric,p_method text,p_details jsonb)
returns public.withdrawals
language plpgsql
security definer
set search_path=public
as $$
declare
  w public.withdrawals;
  available numeric;
  min_amount numeric;
begin
  if auth.uid() is null then raise exception 'Unauthorized'; end if;
  select min_withdrawal into min_amount from public.company_settings limit 1;
  if p_amount < coalesce(min_amount,100) then raise exception 'Minimum withdrawal is ₹100'; end if;

  select
    coalesce(sum(case when e.status='AVAILABLE' then e.amount else 0 end),0)
    - coalesce((select sum(amount) from public.withdrawals x where x.partner_id=auth.uid() and x.status in ('PENDING','UNDER_REVIEW','APPROVED')),0)
  into available
  from public.earnings_ledger e where e.user_id=auth.uid();

  if p_amount > available then raise exception 'Insufficient available balance'; end if;

  insert into public.withdrawals(partner_id,amount,payment_method,payment_details)
  values(auth.uid(),p_amount,p_method,p_details) returning * into w;

  insert into public.audit_logs(actor_id,action,target_type,target_id,after_data)
  values(auth.uid(),'WITHDRAWAL_REQUESTED','withdrawal',w.id,to_jsonb(w));

  return w;
end;
$$;

-- Basic RLS foundation.
alter table public.users enable row level security;
alter table public.profiles enable row level security;
alter table public.packages enable row level security;
alter table public.package_purchases enable row level security;
alter table public.courses enable row level security;
alter table public.course_modules enable row level security;
alter table public.course_chapters enable row level security;
alter table public.course_content enable row level security;
alter table public.course_progress enable row level security;
alter table public.score_events enable row level security;
alter table public.score_balances enable row level security;
alter table public.levels enable row level security;
alter table public.level_requirements enable row level security;
alter table public.notifications enable row level security;
alter table public.projects enable row level security;
alter table public.project_assignments enable row level security;
alter table public.project_messages enable row level security;
alter table public.earnings_ledger enable row level security;
alter table public.withdrawals enable row level security;
alter table public.audit_logs enable row level security;

create or replace function public.my_role() returns public.app_role
language sql stable security definer set search_path=public as $$
  select role from public.users where id=auth.uid();
$$;

drop policy if exists users_self on public.users;
create policy users_self on public.users for select using (id=auth.uid() or public.my_role() in ('CEO','ADMIN'));

drop policy if exists profiles_self on public.profiles;
create policy profiles_self on public.profiles for all using (id=auth.uid() or public.my_role() in ('CEO','ADMIN'));

drop policy if exists packages_read on public.packages;
create policy packages_read on public.packages for select using (active=true or public.my_role() in ('CEO','ADMIN'));

drop policy if exists score_self on public.score_balances;
create policy score_self on public.score_balances for select using (user_id=auth.uid() or public.my_role() in ('CEO','ADMIN'));

drop policy if exists score_events_self on public.score_events;
create policy score_events_self on public.score_events for select using (user_id=auth.uid() or public.my_role() in ('CEO','ADMIN'));

drop policy if exists levels_read on public.levels;
create policy levels_read on public.levels for select using (true);

drop policy if exists course_read on public.courses;
create policy course_read on public.courses for select using (status='PUBLISHED' or public.my_role() in ('CEO','ADMIN'));

drop policy if exists projects_access on public.projects;
create policy projects_access on public.projects for select using (
  client_id=auth.uid()
  or public.my_role() in ('CEO','ADMIN')
  or exists(select 1 from public.project_assignments a where a.project_id=projects.id and a.partner_id=auth.uid())
);

drop policy if exists project_messages_access on public.project_messages;
create policy project_messages_access on public.project_messages for select using (
  sender_id=auth.uid()
  or public.my_role() in ('CEO','ADMIN')
  or exists(select 1 from public.projects p join public.project_assignments a on a.project_id=p.id
            where p.id=project_messages.project_id and (p.client_id=auth.uid() or a.partner_id=auth.uid()))
);

drop policy if exists earnings_self on public.earnings_ledger;
create policy earnings_self on public.earnings_ledger for select using (user_id=auth.uid() or public.my_role() in ('CEO','ADMIN'));

drop policy if exists withdrawals_self on public.withdrawals;
create policy withdrawals_self on public.withdrawals for select using (partner_id=auth.uid() or public.my_role()='CEO');

drop policy if exists notifications_self on public.notifications;
create policy notifications_self on public.notifications for select using (user_id=auth.uid());

-- Never expose audit logs to ordinary users.
drop policy if exists audit_none on public.audit_logs;
create policy audit_none on public.audit_logs for select using (public.my_role() in ('CEO','ADMIN'));

create index if not exists idx_users_role on public.users(role);
create index if not exists idx_users_username on public.users(username);
create index if not exists idx_purchases_user_status on public.package_purchases(user_id,status);
create index if not exists idx_score_events_user_date on public.score_events(user_id,event_date);
create index if not exists idx_projects_status on public.projects(status);
create index if not exists idx_withdrawals_partner_status on public.withdrawals(partner_id,status);
create index if not exists idx_notifications_user_created on public.notifications(user_id,created_at desc);
create index if not exists idx_audit_created on public.audit_logs(created_at desc);

-- Trigger creates the public user/profile record after Supabase Auth signup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.users(id,email,username,name,role,status)
  values(new.id,new.email,coalesce(new.raw_user_meta_data->>'username',split_part(new.email,'@',1)),
         coalesce(new.raw_user_meta_data->>'name',''),'PARTNER','PENDING')
  on conflict(id) do nothing;
  insert into public.profiles(id) values(new.id) on conflict(id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();
