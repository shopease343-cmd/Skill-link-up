-- After creating your first CEO user in Supabase Auth, replace AUTH_USER_UUID below.
-- Run only after the Auth user exists.
update public.users
set role='CEO', status='ACTIVE', first_login_password_change=false
where id='AUTH_USER_UUID';
